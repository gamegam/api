<?php

class Main{

    data.yml = ["app" => null, "Level" => {level}, "API" => "Unity\Kart\Userinfo"];

    public function file(){
        $level = "Android\data\com.nexon.kart\Root\Data/level.class";
        $str = str_replace("{level}", $level);
        return $level;
    }
}