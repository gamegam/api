<?php

use UNIT;

use UNIT\User;

class api UNTI{

$_["API"] = null;
$name = $_["API"];

public function getNick(int $int){
    $name = $_["API"];
    $as = $_data["name"] ?? $_data["Member_number"];
    if (!isset($as)){
        echo "회원번호가 일치하지 않음!";
        return;
        return $as;
    }
}

    /**
     * 게임 시작 정보를 불러옵니다.
     */
    
    public function gameStart(User $user, string $game = null, int $type = 0){
        $type = ["1" => "멀티플레이", "2" => "이어달리기", "랭킹전", "3" => "아케이드모드", "4" => "모든 컨텐츠"];
        if ($type < 1 or $type > 5){
            echo "해당 모드을 찾을 수 없습니다.";
        }else{
            if ($game[$user][$type] == null){//게임 시작을 안한경우
                return $game;
                return true;
            }
            return $game[$user][$type];
        }
    }

    /**
     * 내가 베스트일경우 작동됩니다.
     */

    public function getBest(User $user = null){
        $name = $_["API"];
        $as = $_data["name"] ?? $_data["Member_number"];
        $name = $_data["Best"][$user]["Top"];
        $game = $this->gameStart($as, "", 4);
        if ($name == 1){
            return $name;
        }
    }

    /**
     * 연출 제거
     */

    public function BA(string $list){
        $data = $_data["Skin"];
        foreach ($_data as $name){
            if ($name == $list){
                return $data;
            }
        }
    }

    public function RemoveBest(User $user = null){
        $name = $_["API"];
        $as = $_data["name"] ?? $_data["Member_number"];
        $name = $_data["Best"][$user]["Top"];
        unset($name);
        $this->BA($name);
    }

    public function settime(int $int = 0){
        $time = time() + $int;
        return $time;
    }

    public function getLevel(string $name){
        $api = $_["API"];  
        $level = $api["Level"][$name];
        return $Level;
    }

    /**
     * 프로필 파일을 불러옵니다.
     */

    public function getProfile(string $user = null){
        $use = $name["User"][$name];
        $profile = $name[$user]["Filer"];
        return $profile;
    }

    /**
     * 프로필 변경!
     */

    public function setProfile(string $user, string $file){
        $file = file_exists($user) ?? "test.png";
        if ($file == "test.png"){
            echo "형식이 올바르지 않습니다.";
        }else{
            realpath($user, $file);
            return $file;
        }
    }

    public function isBan(string $name){
        $test = $name["Ban"][$user];
        return $test;
    }

    public function isData(){
        $user = $name["User"]["Device"];
        $version = $name["User"][$version];
        if ($version < $name["Version"]){
            echo "게임을 업데이트 하거나 또는 모드를 업데이트하십시오.";
        }
    }

    public function Mode():void{
        file_get_contents("Mode\src\php");
    }

    public function Che(){
    }
}